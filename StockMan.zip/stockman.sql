-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2016 at 09:46 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stockman`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`type`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`type`) VALUES
('Kids'),
('Men'),
('School'),
('Sports'),
('UniSex'),
('Women');

-- --------------------------------------------------------

--
-- Table structure for table `currentstock`
--

CREATE TABLE IF NOT EXISTS `currentstock` (
  `quantity` int(11) NOT NULL,
  `size` int(2) NOT NULL,
  `itemID` varchar(15) NOT NULL,
  PRIMARY KEY (`itemID`,`size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currentstock`
--

INSERT INTO `currentstock` (`quantity`, `size`, `itemID`) VALUES
(200, 5, 'Item004'),
(200, 6, 'Item004'),
(300, 7, 'Item004'),
(300, 8, 'Item004'),
(100, 9, 'Item004'),
(100, 10, 'Item004'),
(1000, 5, 'Item008'),
(1000, 6, 'Item008'),
(1000, 7, 'Item008'),
(1000, 8, 'Item008'),
(1000, 9, 'Item008'),
(1000, 10, 'Item008'),
(600, 5, 'Item010'),
(200, 6, 'Item010'),
(650, 7, 'Item010'),
(500, 8, 'Item010'),
(300, 9, 'Item010'),
(960, 10, 'Item010'),
(300, 5, 'Item012'),
(300, 6, 'Item012'),
(200, 7, 'Item012'),
(250, 8, 'Item012'),
(250, 9, 'Item012'),
(250, 10, 'Item012'),
(500, 5, 'Item014'),
(500, 6, 'Item014'),
(500, 7, 'Item014'),
(500, 8, 'Item014'),
(500, 9, 'Item014'),
(500, 10, 'Item014');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `category` varchar(100) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `itemID` varchar(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemID`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`category`, `itemName`, `itemID`) VALUES
('Kids', 'Boys', 'Item001'),
('Kids', 'Girls', 'Item002'),
('Kids', 'Infant Shoes', 'Item003'),
('Women', 'High Heels', 'Item004'),
('Women', 'Wedges', 'Item005'),
('Women', 'Flats', 'Item006'),
('Women', 'Casual / Canvas', 'Item007'),
('Men', 'Formal', 'Item008'),
('Men', 'Casual / Canvas', 'Item009'),
('Men', 'Chappals', 'Item010'),
('Men', 'Sandals', 'Item011'),
('School', 'Boys', 'Item012'),
('Sports', 'Girls', 'Item013'),
('School', 'Girls', 'Item014'),
('Sports', 'Running Shoes', 'Item015'),
('Sports', 'Football Shoes', 'Item016'),
('Sports', 'Cricket Shoes', 'Item017'),
('UniSex', 'Bathroom Slippers', 'Item018');

--
-- Triggers `item`
--
DROP TRIGGER IF EXISTS `temp_item`;
DELIMITER //
CREATE TRIGGER `temp_item` BEFORE INSERT ON `item`
 FOR EACH ROW BEGIN
  INSERT INTO temp_item VALUES (NULL);
  SET NEW.itemID = CONCAT('Item', LPAD(LAST_INSERT_ID(), 3, '0'));
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `temp_item`
--

CREATE TABLE IF NOT EXISTS `temp_item` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`itemID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `temp_item`
--

INSERT INTO `temp_item` (`itemID`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18);

-- --------------------------------------------------------

--
-- Table structure for table `temp_transactions`
--

CREATE TABLE IF NOT EXISTS `temp_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `temp_transactions`
--

INSERT INTO `temp_transactions` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35),
(36),
(37),
(38),
(39),
(40),
(41),
(42),
(43);

-- --------------------------------------------------------

--
-- Table structure for table `temp_userdetails`
--

CREATE TABLE IF NOT EXISTS `temp_userdetails` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `temp_userdetails`
--

INSERT INTO `temp_userdetails` (`userID`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `stockID` varchar(20) NOT NULL DEFAULT '0',
  `itemID` varchar(20) NOT NULL,
  `size` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  `userID` varchar(20) NOT NULL,
  `trans` varchar(5) NOT NULL,
  PRIMARY KEY (`stockID`),
  KEY `itemID` (`itemID`),
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`stockID`, `itemID`, `size`, `quantity`, `date`, `userID`, `trans`) VALUES
('stock001', 'Item012', 5, 500, '2016-11-28', '1', 'IN'),
('stock002', 'Item012', 6, 500, '2016-11-28', '1', 'IN'),
('stock003', 'Item012', 7, 500, '2016-11-28', '1', 'IN'),
('stock004', 'Item012', 8, 500, '2016-11-28', '1', 'IN'),
('stock005', 'Item012', 9, 500, '2016-11-28', '1', 'IN'),
('stock006', 'Item012', 10, 500, '2016-11-28', '1', 'IN'),
('stock007', 'Item014', 5, 500, '2016-11-28', '1', 'IN'),
('stock008', 'Item014', 6, 500, '2016-11-28', '1', 'IN'),
('stock009', 'Item014', 7, 500, '2016-11-28', '1', 'IN'),
('stock010', 'Item014', 8, 500, '2016-11-28', '1', 'IN'),
('stock011', 'Item014', 9, 500, '2016-11-28', '1', 'IN'),
('stock012', 'Item014', 10, 500, '2016-11-28', '1', 'IN'),
('stock013', 'Item008', 5, 1000, '2016-11-28', '1', 'IN'),
('stock014', 'Item008', 6, 1000, '2016-11-28', '1', 'IN'),
('stock015', 'Item008', 7, 1000, '2016-11-28', '1', 'IN'),
('stock016', 'Item008', 8, 1000, '2016-11-28', '1', 'IN'),
('stock017', 'Item008', 9, 1000, '2016-11-28', '1', 'IN'),
('stock018', 'Item008', 10, 1000, '2016-11-28', '1', 'IN'),
('stock019', 'Item012', 5, 100, '2016-11-28', '1', 'OUT'),
('stock020', 'Item012', 6, 150, '2016-11-28', '1', 'OUT'),
('stock021', 'Item012', 7, 200, '2016-11-28', '1', 'OUT'),
('stock022', 'Item012', 8, 100, '2016-11-28', '1', 'OUT'),
('stock023', 'Item012', 9, 150, '2016-11-28', '1', 'OUT'),
('stock024', 'Item012', 10, 200, '2016-11-28', '1', 'OUT'),
('stock025', 'Item004', 5, 200, '2016-11-28', '1', 'IN'),
('stock026', 'Item004', 6, 200, '2016-11-28', '1', 'IN'),
('stock027', 'Item004', 7, 300, '2016-11-28', '1', 'IN'),
('stock028', 'Item004', 8, 300, '2016-11-28', '1', 'IN'),
('stock029', 'Item004', 9, 100, '2016-11-28', '1', 'IN'),
('stock030', 'Item004', 10, 100, '2016-11-28', '1', 'IN'),
('stock031', 'Item010', 5, 150, '2016-11-28', '1', 'IN'),
('stock032', 'Item010', 6, 200, '2016-11-28', '1', 'IN'),
('stock033', 'Item010', 7, 650, '2016-11-28', '1', 'IN'),
('stock034', 'Item010', 8, 500, '2016-11-28', '1', 'IN'),
('stock035', 'Item010', 9, 300, '2016-11-28', '1', 'IN'),
('stock036', 'Item010', 10, 960, '2016-11-28', '1', 'IN'),
('stock037', 'Item012', 5, 100, '2016-11-28', '1', 'OUT'),
('stock038', 'Item012', 6, 50, '2016-11-28', '1', 'OUT'),
('stock039', 'Item012', 7, 100, '2016-11-28', '1', 'OUT'),
('stock040', 'Item012', 8, 150, '2016-11-28', '1', 'OUT'),
('stock041', 'Item012', 9, 100, '2016-11-28', '1', 'OUT'),
('stock042', 'Item012', 10, 50, '2016-11-28', '1', 'OUT'),
('stock043', 'Item010', 5, 450, '2016-11-28', '1', 'IN');

--
-- Triggers `transactions`
--
DROP TRIGGER IF EXISTS `temp_transcations`;
DELIMITER //
CREATE TRIGGER `temp_transcations` BEFORE INSERT ON `transactions`
 FOR EACH ROW BEGIN
  INSERT INTO temp_transactions VALUES (NULL);
  SET NEW.stockID = CONCAT('stock', LPAD(LAST_INSERT_ID(), 3, '0'));
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE IF NOT EXISTS `userdetails` (
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `userID` varchar(11) NOT NULL DEFAULT '0',
  `Gender` varchar(10) NOT NULL,
  `tel` varchar(15) NOT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `userID` (`userID`),
  UNIQUE KEY `userID_2` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`username`, `password`, `firstname`, `lastname`, `userID`, `Gender`, `tel`) VALUES
('pdfrulz', '12345678', 'pdf', 'rulz', '1', '', '');

--
-- Triggers `userdetails`
--
DROP TRIGGER IF EXISTS `temp_userdetails`;
DELIMITER //
CREATE TRIGGER `temp_userdetails` BEFORE INSERT ON `userdetails`
 FOR EACH ROW BEGIN
  INSERT INTO temp_userdetails VALUES (NULL);
  SET NEW.userID = CONCAT('Emp', LPAD(LAST_INSERT_ID(), 3, '0'));
END
//
DELIMITER ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `currentstock`
--
ALTER TABLE `currentstock`
  ADD CONSTRAINT `currentstock_ibfk_1` FOREIGN KEY (`itemID`) REFERENCES `item` (`itemID`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `userdetails` (`userID`),
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`itemID`) REFERENCES `item` (`itemID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
